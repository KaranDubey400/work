#ifndef DATE_HPP
#define DATE_HPP

class Date {
private:
    int day, month, year;

public:
    Date();                      // default constructor
    Date(int d, int m, int y);   // parameterized constructor

    void setDay(int d);
    void setMonth(int m);
    void setYear(int y);

    int getDay() const;
    int getMonth() const;
    int getYear() const;

    void accept();               // accept from user
};

#endif
