#include "customer.hpp"
#include <iostream>

Customer::Customer() {
    customername = "not available";
}

Customer::Customer(string name) {
    customername = name;
}

Customer::Customer(const Customer& other) {
    customername = other.customername;
}

void Customer::setCustomerName(string name) {
    customername = name;
}

string Customer::getCustomerName() const {
    return customername;
}

void Customer::accept() {
    cout << "enter customer name: ";
    cin.ignore();
    getline(cin, customername);
}

Customer::~Customer() {
   
}
