#ifndef CUSTOMER_HPP
#define CUSTOMER_HPP

#include <string>
using namespace std;

class Customer
 {
     private:
    string customername;

    public:
    Customer();     

    Customer(string name); 

    Customer(const Customer& other);    

    void setCustomerName(string name);

    string getCustomerName() const;

    void accept();   

    ~Customer();   
                        
};

#endif
