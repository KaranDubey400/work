#ifndef BILL_HPP
#define BILL_HPP

#include "customer.hpp"
#include "date.hpp"
#include <iostream>
using namespace std;

class Bill {
private:
    int billnumber;
    Customer customerinfo;
    Date billdate;
    int billamount;

public:
    Bill();                    

    void setBillNumber(int no);
    void setCustomer(Customer c);
    void setDate(Date d);
    void setAmount(int amt);

    int getAmount() const;
    Customer getCustomer() const;

    void accept();              

    friend ostream& operator<<(ostream& out, const Bill& b);

    ~Bill();                   
};

#endif
