#include "bill.hpp"

Bill::Bill()
 {
    billnumber = 0;
    billamount = 0;
}

void Bill::setBillNumber(int no)
 {
    billnumber = no;
}

void Bill::setCustomer(Customer c)
 {
    customerinfo = c;
}

void Bill::setDate(Date d) {
    billdate = d;
}

void Bill::setAmount(int amt) {
    billamount = amt;
}

int Bill::getAmount() const {
    return billamount;
}

Customer Bill::getCustomer() const {
    return customerinfo;
}

void Bill::accept() {
    cout << "enter bill number ";
    cin >> billnumber;

    customerinfo.accept();
    billdate.accept();

    cout << "Enter bill amount: ";
    cin >> billamount;
}

ostream& operator<<(ostream& out, const Bill& b) {
    out << "\nBill Number : " << b.billnumber
        << "\nCustomer    : " << b.customerinfo.getCustomerName()
        << "\nDate        : " << b.billdate.getDay() << "/"
        << b.billdate.getMonth() << "/"
        << b.billdate.getYear()
        << "\nAmount      : " << b.billamount << "\n";
    return out;
}

Bill::~Bill() {
   
}
