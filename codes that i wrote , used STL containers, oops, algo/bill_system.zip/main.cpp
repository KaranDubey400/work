#include "bill.hpp"
#include <iostream>
using namespace std;

int main() 
{

    Bill bills[3];
    int choice;
    int count = 0;

    do {


        cout << "\n1. accept bill details";
        cout << "\n2. display all bills";

        cout << "\n3. display total bill amount";

        cout << "\n4. display bill for given customer";
        cout << "\n0. exit";

        cout << "\nenter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            for (int i = 0; i < 3; i++) {
                bills[i].accept();
                count++;
            }
            break;

        case 2:
            for (int i = 0; i < count; i++) {
                cout << bills[i];
            }
            break;

        case 3: {
            int total = 0;
            for (int i = 0; i < count; i++)
                total += bills[i].getAmount();

            cout << "total amount: " << total << endl;
            break;
        }

        case 4: {


            string name;
            cout << "customer name: ";
            cin.ignore();
            getline(cin, name);

            for (int i = 0; i < count; i++) {
                if (bills[i].getCustomer().getCustomerName() == name)
                    cout << bills[i];
            }
            break;
        }
        }
    } while (choice != 0);

    return 0;
}
