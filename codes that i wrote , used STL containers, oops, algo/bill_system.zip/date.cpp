#include "date.hpp"
#include <iostream>
#include <stdexcept>
using namespace std;

Date::Date() {
    day = 1;
    month = 1;
    year = 2000;
}

Date::Date(int d, int m, int y) {
    year = y;
    setMonth(m);
    setDay(d);
}

void Date::setMonth(int m) {
    if (m < 1 || m > 12)
        throw std::invalid_argument("Month must be between 1 and 12");
    month = m;
}

void Date::setDay(int d) {
    int maxDay;

    if (month == 2)
        maxDay = 28;
    else if (month == 1 || month == 3 || month == 5 ||
             month == 7 || month == 8 || month == 10 || month == 12)
        maxDay = 31;
    else
        maxDay = 30;

    if (d < 1 || d > maxDay)
        throw std::invalid_argument("Invalid day for given month");

    day = d;
}

void Date::setYear(int y) {
    year = y;
}

int Date::getDay() const { return day; }
int Date::getMonth() const { return month; }
int Date::getYear() const { return year; }

void Date::accept() {
    while (true) {
        try {
            cout << "Enter day month year: ";
            cin >> day >> month >> year;
            setMonth(month);
            setDay(day);
            break;
        } catch (std::exception& e) {
            cout << "Error: " << e.what() << ". Try again.\n";
        }
    }
}
