#include <iostream>
#include <string>
#include <deque>
#include <vector>
#include <map>
#include <stack>
#include <algorithm>
using namespace std; 

//log entry class with event id , event type , severity 
class logentry{
      public: 
       int  Eventid;
      string Eventtype; 
      // high we can take 1 and low as 3 , med 2
       int severitylevel;
     

        logentry() = default; 

        logentry(int id , string type , int severity): Eventid(id) , Eventtype(type) , severitylevel(severity)
        {
        
        }
            
        bool operator == (const logentry &other) const 
        {

            return Eventid == other.Eventid && Eventtype == other.Eventtype && severitylevel == other.severitylevel; 
        
      }

};


enum class severitylvl 
{

      high =1 , medium =2 , low = 3

};

string severitytostr(int str)
{
      if(str==1)
      {
            return "HIGH"; 
      }
      if(str ==2)
      {
          return "MEDIUM";
      }

       return "LOW"; 

}

void printlog(const logentry & ex)
{
      cout<<"ID -"<<ex.Eventid <<" Type" 
      <<ex.Eventtype <<" severity "<< severitytostr(ex.severitylevel)<<endl;

}


int main()
{



     deque<logentry> dq; 

     dq.push_back(logentry(101 , "ERROR", (int)severitylvl::high));

     dq.push_back(logentry(102, "WARNING",(int)severitylvl::medium));

     dq.push_back(logentry(103,"INFO",(int)severitylvl::low));



     for(auto & one :dq)
     {

      cout<<"log added - ID ="<< one.Eventid<<" Type"<<one.Eventtype
      <<" Severity" << severitytostr(one.severitylevel)<<endl;

     }

     vector<logentry> v1(dq.begin(),dq.end());
     
     

     // sorting based on the severity level 
     sort(v1.begin(), v1.end(), [](const logentry &a , const logentry &b ){
          return a.severitylevel < b.severitylevel; 
     });

      int targetid = 102; 

      auto it = find_if(v1.begin(), v1.end(),[&](const  logentry & two){
            return two.Eventid == targetid; 
      });

      (void)it; 


      //erase function and remove from algo
      v1.erase(remove_if (v1.begin(), v1.end(), [](const logentry &three){
                  return three.severitylevel== (int) severitylvl::low;
      }), v1.end()); 

    // to count no. of times each event type occur
      map<string , int> cnt ; 

      for(auto & iter : v1)
      {
            cnt[iter.Eventtype]++;
      }

      // most recently prcessed entry
      stack<logentry> stck; 

       for(auto & iter : v1){
           stck.push(iter); 
       }

       cout<<"\n Processed logs- \n";

       for_each(v1.begin(), v1.end(), [](const logentry & onee){
            printlog(onee); 
       });


       cout<<"\n Event Type Count - \n ";

       for(auto & mvv: cnt){
            cout<<mvv.first << ":"<< mvv.second<<endl;
       }


       cout<<"\nRecently Processed Logs-\n ";

       while(!stck.empty()){
         printlog(stck.top());
         stck.pop(); 
       }









}







