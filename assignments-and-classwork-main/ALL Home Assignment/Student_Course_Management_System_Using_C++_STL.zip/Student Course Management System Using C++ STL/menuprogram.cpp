#include <iostream>
#include "enroll.hpp"
using namespace std;

int main() {

    enroll s1;
    int choice;

    do {
        cout << "\n1. add student";

        cout << "\n2. add course";

        cout << "\n3. enroll student";

        cout << "\n4. remove student from course";

        cout << "\n5. display students";

        cout << "\n6. display courses";

        cout << "\n7. sort students by name";

        cout << "\n8. sort students by department and year";

        cout << "\n9. sort courses by credits";

        cout << "\n0. exit";

        cout << "\nEnter choice: ";

        cin >> choice;

        try {
            switch (choice) {
                case 1:
                 s1.addstudent(); 
                break;

                case 2:
                 s1.addcourse(); 
                break;

                case 3: 
                s1.enrollstudent();
                 break;

                case 4: 
                s1.removestudentfromcourse();
                 break;

                case 5:
                 s1.displaystudents();
                 break;

                case 6: 
                s1.displaycourses();
                 break;

                case 7: 
                s1.sortstudentsbyname(); 
                s1.displaystudents();
                break;

                case 8: 
                s1.sortstudentsbydeptyear();
                s1.displaystudents();
                 break;

                case 9:
                 s1.listcoursesbycredits(); 
                 s1.displaycourses();
                 break;
                 
                case 0: cout << "exit\n"; break;
                
                default: cout << "invalid \n";
            }
         }
        catch (runtime_error &e) {
            cout << "error " << e.what() << endl;
        }

    } while (choice != 0);

    return 0;
}
