#include "enroll.hpp"
#include <algorithm>
#include <iostream>
using namespace std;

// search student by id
void enroll::searchstudentbyid() {
    int sid;
    cout << "enter student id ";
    cin >> sid;

    auto it = find_if(students.begin(), students.end(),[sid](student s) {
            
        return s.getid() == sid;

        });


    if (it == students.end())
     {

        cout << "student not there\n";
    } 
    else
     {
        it->display();
    }

}

// list stu by department

void enroll::liststudentsbydepartment() {
    string dept;
    cout << "enter department== ";
    cin >> dept;

    bool found = false;

    for_each(students.begin(), students.end(), [&](student s)
     {
            if (s.getdepartment() == dept)
             {
                s.display();
                found = true;
            }

        });


    if (!found)
     {
        cout << "no students there\n";
    }
}



void enroll::listcoursesbycredits() {
    int mincredits;
    cout << "Enter minimum credits: ";
    cin >> mincredits;

    for (int i = 0; i < courses.size(); i++) {
        if (courses[i].getcredits() > mincredits) {
            courses[i].display();
        }
    }
}

