#include "enroll.hpp"
#include <algorithm>
#include <iostream>
using namespace std;

//sort by student name
void enroll::sortstudentsbyname() {

    sort(students.begin(), students.end(),[](student a, student b) 

    {
            return a.getname() < b.getname();
            
        });


    cout << "students sorted by name\n";

}

// sort dtudent depart by year

void enroll::sortstudentsbydeptyear() 
{

    sort(students.begin(), students.end(),  [](student a, student b) 
    {
            if (a.getdepartment() == b.getdepartment()) 
            {
                return a.getyear() < b.getyear();
            }

            return a.getdepartment() < b.getdepartment();

        });

    cout << "students sorted by department & year\n";


}


void enroll::sortcoursesbycredits() {

    sort(courses.begin(), courses.end(), [](course a, course b) {
           
        return a.getcredits() > b.getcredits();

        });


    cout << "courses sorted by credits\n";
    
}
