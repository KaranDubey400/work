#include "course.hpp"

course::course(string code, string name, int credits) 
{
    course_code = code;
    course_name = name;
    this->credits = credits;
}

    string course::getcode() 
   {
    return course_code;
    }

   string course::getname() 
   {
    return course_name;
  }

   int course::getcredits()
 {
    return credits;
    }

void course::display() 
    {
    cout << course_code << " "<< course_name << " "<< credits << endl;

    }
