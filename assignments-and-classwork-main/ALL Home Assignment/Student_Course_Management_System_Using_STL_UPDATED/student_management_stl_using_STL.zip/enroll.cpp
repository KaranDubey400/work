#include "enroll.hpp"
#include <stdexcept>
#include <iostream>
using namespace std;



//add stud in vector
void enroll::addstudent() {
    int id, year;
    string name, dept;

    cout << "Enter student id: ";
    cin >> id;

    // check duplicate student id
    for (int i = 0; i < students.size(); i++) {
        if (students[i].getid() == id) {
            throw runtime_error("duplicate studid");
        }
    }

    cout << "enter name";
    cin >> name;

    cout << "department";
    cin >> dept;

    cout << "enter joining date";
    cin >> year;

    student s(id, name, dept, year);
    students.push_back(s);

    cout << "student added sucess\n";
}


// display all students

void enroll::displaystudents() {

    if (students.empty()) {
        cout << "no student fond\n";
        return;
    }

    for (int i = 0; i < students.size(); i++) {
        students[i].display();
    }
}

//enroll ina course
void enroll::addcourse() {

    string code, name;
    int credits;

    cout << "enter coursecode ";
    cin >> code;

    // check duplicate course code
    for (int i = 0; i < courses.size(); i++) {
        if (courses[i].getcode() == code) {
            throw runtime_error("duplicate coursecode");
        }
    }

    cout << "enter coursename ";
    cin >> name;

    cout << "credits ? ";
    cin >> credits;

    course c(code, name, credits);
    courses.push_back(c);

    cout << "course added success\n";


}



void enroll::displaycourses() {

    //cheking if its empty
    if (courses.empty()) {
        cout << "no courses found\n";
        return;
    }

    for (int i = 0; i < courses.size(); i++) {
        courses[i].display();
    }
}



void enroll::enrollstudent() {
    int sid;
    string ccode;

    cout << "enter student id";
    cin >> sid;

    cout << "enter coursecode ";
    cin >> ccode;

 
    bool student_found = false;
    for (int i = 0; i < students.size(); i++) {
        if (students[i].getid() == sid) {
            student_found = true;
            break;
        }
    }
     //eception handling
    if (!student_found) {
        throw runtime_error("student not there");
    }


    bool course_found = false;
    for (int i = 0; i < courses.size(); i++) {
        if (courses[i].getcode() == ccode) {
            course_found = true;
            break;
        }
    }

    //on course exception
    if (!course_found) {
        throw runtime_error("course not present");
    }

    
    if (enrollments[sid].count(ccode)) {
        throw runtime_error("student already enroll in this course");
    }

    enrollments[sid].insert(ccode);
    cout << "enrollment success\n";


}



//rm stud from course
void enroll::removestudentfromcourse() {
    int sid;
    string ccode;

    cout << "enter student_id";
    cin >> sid;

    cout << "enter course code ";
    cin >> ccode;

    if (enrollments.count(sid) == 0) 
    {
        throw runtime_error("student not enroll in any course");
    }

    if (enrollments[sid].count(ccode) == 0)
     {
        throw runtime_error("course not found for this studnt");
    }

    enrollments[sid].erase(ccode);
    
    cout << "course removed success\n";
}


