#include "enroll.hpp"
#include <iostream>
using namespace std;


void enroll::studentwithmaxcourses() {
    if (enrollments.empty()) {
        cout << "no enrollment found\n";
        return;
    }

    int max_courses = 0;
    int student_id = -1;

    for (auto it = enrollments.begin(); it != enrollments.end(); it++)
     {
        if (it->second.size() > max_courses) 
        {
            max_courses = it->second.size();
            student_id = it->first;
        }

    }

    cout << "student with max courses:\n";

    for (int i = 0; i < students.size(); i++)
     {
        if (students[i].getid() == student_id)
         {
            students[i].display();

            cout << "total course" << max_courses << endl;

            break;
        }
    }
}



void enroll::countstudentspercourse() {

    if (courses.empty()) {
        cout << "no courses found\n";
        return;
    }

    for (int i = 0; i < courses.size(); i++)
     {
        string code = courses[i].getcode();
        int count = 0;

        for (auto it = enrollments.begin(); it != enrollments.end(); it++) {
          
            if (it->second.count(code)) {
                count++;
            }

        }

        cout << "course " << code << " -> " << count << " students\n";

    }
}



//display tot al student and course
void enroll::displaytotals() 
{
    cout << "total students " << students.size() << endl;
    cout << "total course " << courses.size() << endl;

}
