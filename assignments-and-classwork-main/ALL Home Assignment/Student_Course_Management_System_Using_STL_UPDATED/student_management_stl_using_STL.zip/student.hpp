#ifndef STUDENT_HPP
#define STUDENT_HPP
#include <iostream>
#include <string>
using namespace std;

class student {
    private:

    int id;
    string name;
    string department;
    int joining_year;

     public:

    student(int id, string name, string department, int year) ;

    int getid();
    string getname();
    string getdepartment();
    int getyear();

    void display();
};

#endif
