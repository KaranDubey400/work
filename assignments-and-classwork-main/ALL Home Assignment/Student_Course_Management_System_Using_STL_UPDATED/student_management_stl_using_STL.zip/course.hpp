#ifndef COURSE_HPP
#define COURSE_HPP
#include <iostream>
#include <string>
using namespace std;

class course {
    string course_code;
    string course_name;
    int credits;

    public:
    course(string code, string name, int credits);

    string getcode();
    string getname();
    
    int getcredits();

    void display();
};

#endif
