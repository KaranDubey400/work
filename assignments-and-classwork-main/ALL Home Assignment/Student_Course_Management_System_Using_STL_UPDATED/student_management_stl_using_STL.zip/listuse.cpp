#include "enroll.hpp"
#include <iostream>
using namespace std;

//display using list
void enroll::displaystudentsincourse() {
    string ccode;
    cout << "Enter course code: ";
    cin >> ccode;

    list<int> student_ids;   

  
    for (auto it = enrollments.begin(); it != enrollments.end(); it++) {
        if (it->second.count(ccode)) {
            student_ids.push_back(it->first);
        }
    }

    if (student_ids.empty()) {
        cout << "No students enrolled in this course\n";
        return;
    }

    //display 
    for (int sid : student_ids) {
        for (int i = 0; i < students.size(); i++) {
            if (students[i].getid() == sid) {
                students[i].display();
            }
        }
    }
}
