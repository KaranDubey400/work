#include <iostream>
#include "enroll.hpp"
using namespace std;

int main() {

    enroll s1;
    int choice;

    do {
        cout << "\n1. add student";

        cout << "\n2. add course";

        cout << "\n3. enroll student";

        cout << "\n4. remove student from course";

        cout << "\n5. display students";

        cout << "\n6. display courses";

        cout << "\n7. sort students by name";

        cout << "\n8. sort students by department and year";

        cout << "\n9. sort courses by credits";

        cout << "\n10. search student by id";
        
        cout << "\n11. list students by department";
        
        cout << "\n12. list courses by min credits";
        
        cout << "\n13. student with max enrollments";
        
        cout << "\n14. count students per course";
         
        cout << "\n15. display totals";

        cout<<"\n16. display students in course";

        cout << "\n0. exit";

        cout << "\nEnter choice: ";

        cin >> choice;

        try {
            switch (choice) {
                case 1:
                 s1.addstudent(); 
                break;

                case 2:
                 s1.addcourse(); 
                break;

                case 3: 
                s1.enrollstudent();
                 break;

                case 4: 
                s1.removestudentfromcourse();
                 break;

                case 5:
                 s1.displaystudents();
                 break;

                case 6: 
                s1.displaycourses();
                 break;

                case 7: 
                s1.sortstudentsbyname(); 
                break;

                case 8: 
                s1.sortstudentsbydeptyear();
    
                 break;

                case 9:
                 s1.sortcoursesbycredits();
                
                 break;

                 case 10:
                  s1.searchstudentbyid();
                  
                  break;
                  
                   case 11: 
                   s1.liststudentsbydepartment(); 
                
                   break;
           
                 case 12: 
                 s1.listcoursesbymincredits();
                 
                 break;

               case 13: 
                s1.studentwithmaxcourses(); 
                  
                break;

                case 14:
                s1.countstudentspercourse();
                break;

                case 15:
                s1.displaytotals();
                break;

                case 16:
                s1.displaystudentsincourse();
                break;


       
                case 0: cout << "exit\n"; break;
                
                default: cout << "invalid \n";
            }
         }
        catch (runtime_error &e) {
            cout << "error " << e.what() << endl;
        }

    } while (choice != 0);

    return 0;
}
