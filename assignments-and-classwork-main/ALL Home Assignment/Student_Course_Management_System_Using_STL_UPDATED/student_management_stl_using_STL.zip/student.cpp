#include "student.hpp"


      student::student(int id, string name, string department, int year) 
   {
    this->id = id;
    this->name = name;
    this->department = department;
    this->joining_year = year;
  }

       int student::getid() {
    return id;
}

       string student::getname()
    {
    return name;
    }

     string student::getdepartment()  
   {
    return department;
    }

      int student::getyear() 
      {
    return joining_year;
}

     void student::display() {

    cout << id << " "  << name << " "<< department << " " << joining_year << endl;

}
