#ifndef ENROLL_HPP
#define ENROLL_HPP
#include <vector>
#include <map>
#include <set>
#include <list>
#include <stdexcept>
#include "student.hpp"
#include "course.hpp"
using namespace std;

class enroll 
{

    private:

    //storing student & course
    vector<student> students;
    vector<course> courses;

   //to store unique , no duplicate
    map<int, set<string>> enrollments;


    public:
    //function declaration
    void addstudent();
    void displaystudents();

    void addcourse();
    void displaycourses();

    void enrollstudent();

    
//remove 
      void removestudentfromcourse();


  // searching & filter
  void searchstudentbyid();
  void liststudentsbydepartment();
  void listcoursesbymincredits();

  // sort
  void sortstudentsbyname();
  void sortstudentsbydeptyear();
  void sortcoursesbycredits();


  

  // stats
        void studentwithmaxcourses();
       void countstudentspercourse();
       void displaytotals();

     void displaystudentsincourse();



};

#endif
