## this directory contains PDF of assignment 1 done by me as a part of ongoing training 
directory also contains the cpp codes for the same