## this directory contains PDF of assignment 2 done by me as a part of the training 
Directory also contains the cpp files  , total 6 probelms 