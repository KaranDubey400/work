int & operator [] (int a){
    if (a>4 || a<0){

    }
    return arr[a]
;}