#include "calc_header.hpp"

int main() {
    add(10, 5);
    sub(10, 5);
    mul(10, 5);
    div_func(10, 5);
    
    return 0;
}