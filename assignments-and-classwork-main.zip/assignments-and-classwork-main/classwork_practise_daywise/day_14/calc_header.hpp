#ifndef CALC_HEADER_HPP
#define CALC_HEADER_HPP


int add(int n1, int n2);
int sub(int n1, int n2);
int mul(int n1, int n2);
int div_func(int n1, int n2);

#endif