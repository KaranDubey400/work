#include <iostream>
using namespace std;
int n;
int main()
{
	while(cin>>n)
	{
		cout<<n<<" ";
	}
}
