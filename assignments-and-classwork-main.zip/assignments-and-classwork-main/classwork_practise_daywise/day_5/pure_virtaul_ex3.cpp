#include <iostream>
using namespace std;

class base {
    public :
    virtual void test()= 0; 
};

class der :public base 
{

};

str[i-1];
str.at(i-1);
int main (){
    der dd;
}

