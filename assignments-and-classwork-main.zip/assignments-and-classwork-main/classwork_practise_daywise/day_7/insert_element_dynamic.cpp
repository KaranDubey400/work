#include <iostream>
using namespace std;
int main(){
    double * p1 , *p2;
}