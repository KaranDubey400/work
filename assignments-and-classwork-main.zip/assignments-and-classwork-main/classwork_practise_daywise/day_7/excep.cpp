//exception specification are put along with function declaration 

#include <iostream>
using namespace std;

void test(int ,int) throw(e1,e2,e3);