#include <iostream>
using namespace std;
int main()
{
	const int x=10;
	x=x+5;
	cout<<x<<endl;
	int y;
	20=y;
}
