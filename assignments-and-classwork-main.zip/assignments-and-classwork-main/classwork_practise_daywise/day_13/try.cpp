#include <iostream>
#include "inline_header.hpp"
using namespace std;
int main()
{
	cout<<invar<<endl;
}
