day26 to day29  we worked in a team of 4 
to implement telemetry pipline code 

topics learned  and implemented - inter process communication , posix shared memory , mutex , read write lock , file     operations   multi process , memory mapping , synchronization , linked list 


          divided the program into three files , generator , analyzer , monitor 
         
         compiled these files to get the output file using command gcc filename.c -o output -pthread

         to run it, and test it , first we started monitor  . then analyzer, then generator  


         