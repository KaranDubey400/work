# Assignments and classwork    11 DEC -14FEB


This is the collection of the Home assignments that were assigned to me during my Pre-Skill training 


This repo also contains the (class_assignment  ) 

daily codes , daywise that i have completed , are in daywise section... did during the class... every day if we do any particualar code or as asked by trainer , i complete those and then upload it here in DayWise section , u can find everything i did during classes in daywise directory

